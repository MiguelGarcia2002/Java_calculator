
import java.util.*;
public class Calculator

{
    /**
     * Standard public static void main method, this is essentially the method that operates the calculator.
     * @param args - Standard String[] args parameter
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Stack<Integer> numStack = new Stack<>();
        Stack<Character> opStack = new Stack<>();

        /**
         * While loop that keeps running the calculator, inside the while loop is the print statements that ask for the
         * user to input a problem. This is where the stacks are used to store the numbers and operators in the respective
         * stacks.
         */
        while(true){
            System.out.println("Please enter an expression to solve");
            String problem = scan.nextLine();
            if(problem.equalsIgnoreCase("DONE"))
                break;

            /**
             * This for loop iterates through each character in the problem the user inputs. At this point it only checks
             * for integers that could possibly have starting 0s, and combines larger numbers together using getOp.
             */
            for (int i = 0; i < problem.length(); i++) {
                if (Character.isDigit(problem.charAt(i))) {
                    int val = getOp(problem, i);
                    while(i < problem.length() && Character.isDigit(problem.charAt(i)))
                        i++;
                    i--;
                    numStack.push(val);
                }

                /**
                 * These if-else statements check for any operators that the user input. First it checks if the operation
                 * stack is empty and that the char it found is '+' or '-', then it pushes that operator to the
                 * operation stack. The if-else checks to see if the operation stack isn't empty to perform some calculations.
                 * If the stack isn't empty it'll do addition or subtraction with the previous operation and the last two
                 * numbers in the number stack. Afterwards it pushes the new value and the latest operation to their
                 * respective stacks.
                 */
                if (opStack.isEmpty() && (problem.charAt(i) == '+' || problem.charAt(i) == '-')) {
                    opStack.push(problem.charAt(i));
                } else if (!opStack.isEmpty() && ((problem.charAt(i) == '+' || problem.charAt(i) == '-'))) {
                    char check = opStack.peek();
                    if (check == '+' || check == '-') {
                        char newExpression = opStack.pop();
                        int val1 = numStack.pop();
                        int val2 = numStack.pop();
                        int newVal = Calculate(val2, val1, newExpression);
                        numStack.push(newVal);
                        opStack.push(problem.charAt(i));
                    } else
                        opStack.push(problem.charAt(i));
                }


                /**
                 * This is a simple if statement that checks for an open parenthesis in the String, if it finds an open
                 * parenthesis it will be added to the operator stack.
                 */
                if (problem.charAt(i) == '(') {
                    opStack.push(problem.charAt(i));
                }

                /**
                 * This is the if statement that checks for any closed parenthesis in the String. It starts by peeking
                 * and recording the first operator in the operation stack, a while loop starts that checks that the variable
                 * holding the current operator isn't an open parenthesis. After this there will be and if and if-else
                 * check. If the stack contains multiple expressions then it'll constantly keep doing the operations
                 * and pushing the new values in the stack, the char variable is constantly updated to the latest operation
                 * in the stack. if the stack with the numbers only has one number, then it'll mainly check to see if it's
                 * a negative number. It'll pop and record the expression, if the expression is a '-' it'll turn the current
                 * number negative and be pushed back into the number stack. At the end of the if statement it'll pop the
                 * open parenthesis.
                 */
                if (problem.charAt(i) == ')') {
                    char poke = opStack.peek();
                    while (poke != '(') {
                        if(numStack.size() > 1) {
                            char newExpression = opStack.pop();
                            int val1 = numStack.pop();
                            int val2 = numStack.pop();
                            int newVal = Calculate(val2, val1, newExpression);
                            numStack.push(newVal);
                            poke = opStack.peek();
                        }
                        else if(numStack.size() == 1 && ((poke == '+' || poke == '-'))){
                            char express = opStack.pop();
                            if(express == '-'){
                                int val = numStack.pop() * -1;
                                numStack.push(val);
                            }
                            poke=opStack.peek();
                        }
                    }
                    opStack.pop();
                }
            }

            /**
             * This is the end of the whole program, after the for loop has gone through all characters in the String one of
             * two cases will happen: either there are two numbers in the stack with one final operation left, or there is
             * only one number in the stack that is either positive or negative. If there are two numbers in the stack then
             * it'll calculate the last two numbers and throw the result to the number stack. If there's only one number
             * in the number stack, and one operator in the operators stack then it'll only check if the number should be
             * negative or not. Whether it's negative or not it'll be thrown in the number stack.
             */
            if (!opStack.isEmpty()) {
                if(numStack.size() >=2) {
                    char newExpression = opStack.pop();
                    int val1 = numStack.pop();
                    int val2 = numStack.pop();
                    int newVal = Calculate(val2, val1, newExpression);
                    numStack.push(newVal);
                }
                else if(numStack.size() == 1 && opStack.size()==1){
                    char express = opStack.pop();
                    if(express == '-'){
                        int val = numStack.pop() * -1;
                        numStack.push(val);
                    }
                }
            }
            /**
             * At the end of the program it'll print the result, which is done by popping the final number in the number
             * stack, this also empties both stacks.
             */
            System.out.println("Result : " + numStack.pop());
            numStack.removeAllElements();
            opStack.removeAllElements();
        }
    }


    /**
     * This is the calculate method that ads or subtracts based on the operation. The method takes in three parameters:
     * two int variables and a char. it first defines an int val "newVal" and performs an operation with the parameters.
     * if the operation is a '+' it does addition, otherwise it will subtract. At the end of the operation the method
     * returns the newVal int that's calculated.
     * @param num1 - int first number parameter
     * @param num2 - int second number parameter
     * @param operation - char operation parameter
     * @return - returns newVal int after calculations have been completed.
     */
    public static int Calculate(int num1, int num2, char operation){
        int newVal;
        if(operation == '+')
            newVal = num1+num2;
        else
            newVal = num1-num2;
        return newVal;
    }


    /**
     * This is the getOp method, the main function of this method is to combine single digit numbers to form a full number
     * to do the complete calculations.
     * @param exp - String parameter
     * @param cur - int parameter
     * @return - returns the full integer.
     */
    private static int getOp(String exp, int cur){
        Scanner s = new Scanner(exp.substring(cur));
        s.useDelimiter("[^0-9]");
        return s.nextInt();
    }

}
